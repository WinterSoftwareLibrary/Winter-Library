# Winter Interface Suite

A UI library for Roblox, originally based on Luna Interface Suite by Nebula Softworks.

#### Features
- Key system with both permanent ("Simple") and time-limited ("Time") key support
- Info/Home tab showing your avatar, executor support, server stats, and key status
- Custom configs, prebuilt tabs, theming, and more

----

[![luna](https://github.com/user-attachments/assets/c0e73e67-0595-4872-919d-5f2329293186)](https://discord.com/channels/1123950497347424357/1306516017262104637)  

###### [Documentation And Example](https://github.com/Nebula-Softworks/Luna-Interface-Suite/blob/main/Documentation.md)
